<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Season extends Model
{
	//number é o número da temporada.
    protected $fillable = [
        'description', 'actual', 'value', 'number', 'start', 'end'
    ];

    //functions

    public function getSeasons(){
        return $this->orderBy('actual','DESC')->get();
    }

    public function getByIdWithMatches($id){
        return $this->where('id', '=', $id)
            ->with(array('matches' => function($q){
                            $q->orderBy('date_match', 'DESC');
                    }))->get();
    }

    public function saveAndIncNumber($season){
        $season->number = Season::max('number') + 1;
        $season->save();
    }

    //Relacionamentos

    public function matches()
    {
    	return $this->hasMany('App\Match');
    }

    public function users(){
    	return $this->belongsToMany('App\User')->withPivot('payment', 'date_payment');
    }
}
