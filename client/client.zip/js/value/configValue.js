angular.module('pelenio').value('config', {
//	baseUrlApi: "http://localhost/api"
	baseUrlApi: "http://192.168.2.108/api"
});