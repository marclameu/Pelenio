angular.module("pelenio", ["ngRoute", "ngMessages", "ngStorage", "ngAnimate", "ui.mask", 
						   "ui.utils.masks", "ngLocale", "ngDialog", "ngToast", "ui.bootstrap"]);